
#List
userNames=['admin','manager','qa',12,True]

for uname in userNames:
    print(uname)

for i in range(10):
    print(i)

