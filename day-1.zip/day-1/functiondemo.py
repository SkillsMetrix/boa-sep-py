
def showWelcome():
    print(' welcome called')

def calculate(x,y):
    return x+y

showWelcome()

print(calculate(12,13))