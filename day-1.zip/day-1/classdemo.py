
class User:
    name='shashi'
    state='MH'

    # constructor
    def __init__(self,email="user@mail.com",city="pune"):

        self.email=email
        self.city=city
    # it calls when printing object
    def __str__(self):
        return f"{self.email} -{self.city} "

    # regular method
    def printData(self):
        print(self.name,self.state)

# creating object
userdata= User(email="admin@mail.com",city="Chennai")
print(userdata)
userdata.printData()

