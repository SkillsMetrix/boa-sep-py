print('welcome to python')

# this is comment
# declare the variables

name="Admin"
city="Mumbai"
age=20

print(name,city,age)

print("My Name is ", name, "My City is ", city, "Age is ",age)

print(f"My Name is {name} my city is {city} and age is {age}")

a=10
if a > 10:
    print('its true')
else:
    print('its false')