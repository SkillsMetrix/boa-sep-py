
def sumOfArray(arr):
    total=0
    for num in arr:
        total +=num
    return total

data=[23,45,65,78]

result= sumOfArray(data)
print(f"The calculation is  {result}")

    