
# declare empty list

use_numbers=[]

data= int(input('How many numbers you wanna add:  '))

for i in range(data):
    num= int(input(f"Enter Number {i}: "))
    use_numbers.append(num)
print(f"the collected data {use_numbers}")

# check even or add
for newdata in use_numbers:
    if(newdata%2 ==0):
        print(f"{newdata} is even")
    else:
        print(f"{newdata} is odd")


