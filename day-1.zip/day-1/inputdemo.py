
a = int(input('Enter First Value '))
b = int(input('Enter Second Value '))
c=a+b
print(f"Addition is : {c}")