
from inheritence import RBI

class SBI(RBI):
    balance=100
    def withdraw(self,amount):
         if amount > self.balance:
            print('invalid amount, not enough balance')
         else:
            self.balance -=amount
         
    def checkBalance(self):
        print('Available  balance ', self.balance)
    def depositAmount(self,amount):
        self.balance +=amount

    def openSalaryAccount(self):
        print("Salary Acc opened in SBI")

bank= SBI()
 
bank.checkBalance()
bank.depositAmount(100)
bank.checkBalance()
bank.withdraw(100)
bank.checkBalance()
