


class HDFC(RBI):

    def withdraw(amount):
         print("withdraw in HDFC")


    def openSalaryAccount(self):
        print("Salary Acc opened in HDFC")

bank= HDFC()
bank.openSalaryAccount()
bank.withdraw()